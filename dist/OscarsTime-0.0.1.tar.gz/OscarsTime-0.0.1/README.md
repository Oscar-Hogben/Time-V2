# Timer Module
## Getting Started:
* To use put ***'main.py'*** in the same directory of your script
* Type `from TimerModule import Timer`
## How to use:
* To access the features of the timer module type `Timer.` followed by the feature you would like to access
## Features:
* `Timer.timer()` - Starts a asynchronous timer. Arguments: 1st: timer length (seconds), 2nd: Timer completed message (string) (default = "Timer Completed")
* 